# Social Chat Backend

This is the backend for a social chat app using Node.js, Express, MongoDB, and Socket.IO.